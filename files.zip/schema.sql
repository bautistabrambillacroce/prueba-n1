-- ============================================================
-- Búsqueda del tesoro geolocalizada · esquema Supabase
-- Ejecutar completo en: Supabase > SQL Editor > New query
-- Las tablas NO son accesibles desde el navegador (RLS sin políticas):
-- todo pasa por funciones RPC que validan en el servidor.
-- ============================================================
create extension if not exists pgcrypto with schema extensions;

create table if not exists game (
  id int primary key default 1 check (id = 1),
  name text not null default 'Búsqueda del tesoro',
  join_code text not null default 'TESORO',
  duration_min int not null default 240,
  base_points int not null default 100,
  speed_bonus_max int not null default 50,   -- pierde 1 punto cada 30 s desde el punto anterior
  hint_cost int not null default 10,
  story_intro text,
  story_outro text
);
insert into game default values on conflict do nothing;

create table if not exists admins (email text primary key);

create table if not exists points (
  id text primary key,
  ord int unique not null,
  name text,
  lat double precision not null,
  lon double precision not null,
  radius_m int not null default 30,
  clue text not null,
  story text,
  hint text,
  challenge_q text,
  challenge_a text,           -- alternativas separadas por |
  token_hash text not null,   -- sha256 hex del token del QR
  backup_hash text not null   -- sha256 hex del código manual (MAYÚSCULAS)
);

create table if not exists teams (
  id uuid primary key default gen_random_uuid(),
  secret uuid not null default gen_random_uuid(),
  name text unique not null,
  started_at timestamptz not null default now(),
  finished_at timestamptz,
  score int not null default 0,
  last_submit timestamptz
);

-- Datos personales: solo accesibles por el organizador (Ley 25.326)
create table if not exists players (
  id bigserial primary key,
  team_id uuid not null references teams on delete cascade,
  full_name text not null,
  age int not null,
  phone text not null,
  instagram text,
  guardian_ok boolean not null default false,
  consent boolean not null check (consent)
);

create table if not exists progress (
  team_id uuid references teams on delete cascade,
  point_id text references points on delete cascade,
  at timestamptz not null default now(),
  pts int not null,
  used_backup boolean not null default false,
  dist_m double precision,
  accuracy_m double precision,
  primary key (team_id, point_id)
);

create table if not exists hints (
  team_id uuid references teams on delete cascade,
  point_id text references points on delete cascade,
  primary key (team_id, point_id)
);

alter table game enable row level security;
alter table admins enable row level security;
alter table points enable row level security;
alter table teams enable row level security;
alter table players enable row level security;
alter table progress enable row level security;
alter table hints enable row level security;
revoke all on all tables in schema public from anon, authenticated;

-- ---------- utilidades ----------
create or replace function haversine_m(lat1 float8, lon1 float8, lat2 float8, lon2 float8)
returns float8 language sql immutable as $$
  select 2 * 6371000 * asin(least(1, sqrt(
    power(sin(radians(lat2 - lat1) / 2), 2) +
    cos(radians(lat1)) * cos(radians(lat2)) * power(sin(radians(lon2 - lon1) / 2), 2))));
$$;

create or replace function is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from admins where email = auth.jwt() ->> 'email');
$$;

create or replace function _sha(t text) returns text
language sql immutable set search_path = public, extensions as $$
  select encode(digest(t, 'sha256'), 'hex');
$$;

-- ---------- jugadores ----------
create or replace function register_team(p_code text, p_name text, p_players jsonb)
returns json language plpgsql security definer set search_path = public, extensions as $$
declare g game; t teams; pl jsonb;
begin
  select * into g from game;
  if upper(trim(p_code)) <> upper(g.join_code) then raise exception 'Código de partida incorrecto'; end if;
  if length(trim(p_name)) < 2 or length(trim(p_name)) > 40 then raise exception 'Nombre de equipo inválido'; end if;
  if jsonb_array_length(p_players) < 1 or jsonb_array_length(p_players) > 6 then
    raise exception 'El equipo debe tener entre 1 y 6 participantes'; end if;
  insert into teams (name) values (trim(p_name)) returning * into t;
  for pl in select * from jsonb_array_elements(p_players) loop
    if coalesce((pl ->> 'consent')::boolean, false) is not true then raise exception 'Falta el consentimiento'; end if;
    if (pl ->> 'age')::int < 18 and coalesce((pl ->> 'guardian_ok')::boolean, false) is not true then
      raise exception 'Menores de 18: se requiere autorización de madre, padre o tutor'; end if;
    insert into players (team_id, full_name, age, phone, instagram, guardian_ok, consent)
    values (t.id, trim(pl ->> 'full_name'), (pl ->> 'age')::int, trim(pl ->> 'phone'),
            nullif(trim(pl ->> 'instagram'), ''), coalesce((pl ->> 'guardian_ok')::boolean, false), true);
  end loop;
  return json_build_object('team_id', t.id, 'secret', t.secret);
exception when unique_violation then raise exception 'Ya existe un equipo con ese nombre';
end $$;

create or replace function get_state(p_team uuid, p_secret uuid)
returns json language plpgsql security definer set search_path = public, extensions as $$
declare t teams; g game; p points; done int; total int; hint_used boolean;
begin
  select * into t from teams where id = p_team and secret = p_secret;
  if not found then raise exception 'Equipo inválido'; end if;
  select * into g from game;
  select count(*) into done from progress where team_id = t.id;
  select count(*) into total from points;
  select * into p from points where ord = done + 1;
  hint_used := exists (select 1 from hints h where h.team_id = t.id and h.point_id = p.id);
  return json_build_object(
    'team', t.name, 'score', t.score, 'now', now(),
    'ends_at', t.started_at + make_interval(mins => g.duration_min),
    'done', done, 'total', total, 'finished', t.finished_at is not null,
    'intro', g.story_intro, 'outro', case when t.finished_at is not null then g.story_outro end,
    'hint_cost', g.hint_cost,
    'story', (select coalesce(json_agg(story order by ord), '[]') from points where ord <= done and story is not null),
    'point', case when p.id is null then null else json_build_object(
      'ord', p.ord, 'clue', p.clue, 'challenge', p.challenge_q,
      'hint', case when hint_used then p.hint end, 'has_hint', p.hint is not null) end);
end $$;

create or replace function use_hint(p_team uuid, p_secret uuid)
returns json language plpgsql security definer set search_path = public, extensions as $$
declare t teams; p points; done int;
begin
  select * into t from teams where id = p_team and secret = p_secret;
  if not found then raise exception 'Equipo inválido'; end if;
  select count(*) into done from progress where team_id = t.id;
  select * into p from points where ord = done + 1;
  if p.hint is null then return json_build_object('hint', null); end if;
  insert into hints values (t.id, p.id) on conflict do nothing;
  return json_build_object('hint', p.hint);
end $$;

-- Llegada: orden, geocerca (haversine), token y desafío se verifican acá.
create or replace function submit_arrival(
  p_team uuid, p_secret uuid, p_lat float8, p_lon float8, p_acc float8,
  p_token text default null, p_backup text default null, p_answer text default null)
returns json language plpgsql security definer set search_path = public, extensions as $$
declare t teams; g game; p points; done int; total int; d float8;
        prev timestamptz; bonus int; spent int; pts int; via_backup boolean := false;
begin
  select * into t from teams where id = p_team and secret = p_secret for update;  -- serializa envíos simultáneos
  if not found then raise exception 'Equipo inválido'; end if;
  select * into g from game;
  if t.finished_at is not null then return json_build_object('ok', false, 'error', 'Ya completaron el recorrido'); end if;
  if now() > t.started_at + make_interval(mins => g.duration_min) then
    return json_build_object('ok', false, 'error', 'Se terminó el tiempo'); end if;
  if t.last_submit is not null and now() - t.last_submit < interval '2 seconds' then
    return json_build_object('ok', false, 'error', 'Esperá unos segundos antes de reintentar'); end if;
  update teams set last_submit = now() where id = t.id;

  select count(*) into done from progress where team_id = t.id;
  select * into p from points where ord = done + 1;   -- el orden lo decide el servidor
  if p.id is null then return json_build_object('ok', false, 'error', 'No quedan puntos'); end if;

  if coalesce(p_backup, '') <> '' then
    if _sha(upper(trim(p_backup))) <> p.backup_hash then
      return json_build_object('ok', false, 'error', 'Código de respaldo incorrecto'); end if;
    via_backup := true;
  else
    if p_lat is null or p_lon is null then
      return json_build_object('ok', false, 'error', 'No se recibió la ubicación'); end if;
    d := haversine_m(p_lat, p_lon, p.lat, p.lon);
    -- se perdona la imprecisión reportada del GPS, con tope de 25 m
    if d > p.radius_m + least(greatest(coalesce(p_acc, 0), 0), 25) then
      return json_build_object('ok', false, 'error', 'Todavía no llegaste al punto', 'distance_m', round(d / 10) * 10); end if;
    if _sha(trim(coalesce(p_token, ''))) <> p.token_hash then
      return json_build_object('ok', false, 'error', 'QR inválido para este punto'); end if;
  end if;

  if coalesce(p.challenge_a, '') <> '' then
    if lower(trim(coalesce(p_answer, ''))) <> all (string_to_array(lower(p.challenge_a), '|')) then
      return json_build_object('ok', false, 'error', 'Respuesta incorrecta'); end if;
  end if;

  select coalesce(max(at), t.started_at) into prev from progress where team_id = t.id;
  bonus := greatest(0, g.speed_bonus_max - floor(extract(epoch from now() - prev) / 30)::int);
  spent := case when exists (select 1 from hints where team_id = t.id and point_id = p.id) then g.hint_cost else 0 end;
  pts := greatest(0, g.base_points + bonus - spent);
  insert into progress (team_id, point_id, pts, used_backup, dist_m, accuracy_m)
  values (t.id, p.id, pts, via_backup, d, p_acc);
  select count(*) into total from points;
  update teams set score = score + pts,
         finished_at = case when done + 1 >= total then now() end
   where id = t.id;
  return json_build_object('ok', true, 'pts', pts, 'bonus', bonus);
end $$;

create or replace function leaderboard()
returns table (name text, done bigint, score int, finished boolean, elapsed_s int)
language sql security definer set search_path = public as $$
  select t.name, (select count(*) from progress pr where pr.team_id = t.id), t.score,
         t.finished_at is not null,
         extract(epoch from coalesce(t.finished_at, now()) - t.started_at)::int
  from teams t order by t.score desc, t.finished_at asc nulls last;
$$;

-- ---------- organizador (requiere login + estar en la tabla admins) ----------
create or replace function admin_teams() returns json
language plpgsql security definer set search_path = public as $$
begin
  if not is_admin() then raise exception 'No autorizado'; end if;
  return (select coalesce(json_agg(x), '[]') from (
    select t.id, t.name, t.score, t.started_at, t.finished_at,
      (select count(*) from progress p where p.team_id = t.id) as done,
      (select count(*) from progress p where p.team_id = t.id and p.used_backup) as backups,
      (select avg(accuracy_m) from progress p where p.team_id = t.id) as avg_acc,
      (select json_agg(json_build_object('name', full_name, 'age', age, 'phone', phone, 'instagram', instagram))
         from players pl where pl.team_id = t.id) as players
    from teams t order by t.score desc) x);
end $$;

create or replace function admin_reset() returns void
language plpgsql security definer set search_path = public as $$
begin
  if not is_admin() then raise exception 'No autorizado'; end if;
  delete from teams where true;   -- cascada: jugadores, progreso, pistas usadas
end $$;

-- Carga el JSON de configuración (ver config/game.example.json)
create or replace function admin_load_config(cfg jsonb) returns void
language plpgsql security definer set search_path = public, extensions as $$
declare v int := coalesce((cfg ->> 'variant')::int, 0); th jsonb; e record; pv jsonb; pt jsonb;
begin
  if not is_admin() then raise exception 'No autorizado'; end if;
  th := cfg -> 'themes' -> (v % jsonb_array_length(cfg -> 'themes'));
  update game set name = cfg ->> 'name',
    join_code = cfg ->> 'joinCode',
    duration_min = coalesce((cfg ->> 'durationMin')::int, 240),
    base_points = coalesce((cfg #>> '{scoring,base}')::int, 100),
    speed_bonus_max = coalesce((cfg #>> '{scoring,speedBonusMax}')::int, 50),
    hint_cost = coalesce((cfg #>> '{scoring,hintCost}')::int, 10),
    story_intro = th ->> 'intro', story_outro = th ->> 'outro';
  delete from teams where true;
  delete from points where true;
  for e in select * from jsonb_array_elements(cfg -> 'points') with ordinality as t(value, n) loop
    pt := e.value;
    pv := pt -> 'variants' -> (v % jsonb_array_length(pt -> 'variants'));
    insert into points (id, ord, name, lat, lon, radius_m, clue, story, hint, challenge_q, challenge_a, token_hash, backup_hash)
    values (pt ->> 'id', e.n, pt ->> 'name', (pt ->> 'lat')::float8, (pt ->> 'lon')::float8,
      coalesce((pt ->> 'radius')::int, (cfg ->> 'radiusDefault')::int, 30),
      pv ->> 'clue', pv ->> 'story', pv ->> 'hint', pv ->> 'challenge', pv ->> 'answer',
      lower(pt ->> 'tokenHash'), _sha(upper(trim(pt ->> 'backupCode'))));
  end loop;
end $$;

-- ---------- permisos ----------
revoke execute on all functions in schema public from public, anon, authenticated;
grant execute on function register_team(text, text, jsonb) to anon, authenticated;
grant execute on function get_state(uuid, uuid) to anon, authenticated;
grant execute on function use_hint(uuid, uuid) to anon, authenticated;
grant execute on function submit_arrival(uuid, uuid, float8, float8, float8, text, text, text) to anon, authenticated;
grant execute on function leaderboard() to anon, authenticated;
grant execute on function admin_teams() to authenticated;
grant execute on function admin_reset() to authenticated;
grant execute on function admin_load_config(jsonb) to authenticated;
